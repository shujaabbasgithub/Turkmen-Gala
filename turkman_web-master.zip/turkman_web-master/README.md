# React + TypeScript + Vite

- install node - npm install
- run server - npm run dev
- run build - npm run build